<?php _x( 'Afrikaans', 'language name', 'wp-typography' ); ?>
<?php _x( 'Amharic', 'language name', 'wp-typography' ); ?>
<?php _x( 'Assamese', 'language name', 'wp-typography' ); ?>
<?php _x( 'Belarusian', 'language name', 'wp-typography' ); ?>
<?php _x( 'Bulgarian', 'language name', 'wp-typography' ); ?>
<?php _x( 'Bengali', 'language name', 'wp-typography' ); ?>
<?php _x( 'Catalan', 'language name', 'wp-typography' ); ?>
<?php _x( 'Czech', 'language name', 'wp-typography' ); ?>
<?php _x( 'Church Slavonic', 'language name', 'wp-typography' ); ?>
<?php _x( 'Welsh', 'language name', 'wp-typography' ); ?>
<?php _x( 'Danish', 'language name', 'wp-typography' ); ?>
<?php _x( 'German (Traditional)', 'language name', 'wp-typography' ); ?>
<?php _x( 'German (Swiss Traditional)', 'language name', 'wp-typography' ); ?>
<?php _x( 'German', 'language name', 'wp-typography' ); ?>
<?php _x( 'Greek (Modern Monotonic)', 'language name', 'wp-typography' ); ?>
<?php _x( 'Greek (Modern Polytonic)', 'language name', 'wp-typography' ); ?>
<?php _x( 'English (United Kingdom)', 'language name', 'wp-typography' ); ?>
<?php _x( 'English (United States)', 'language name', 'wp-typography' ); ?>
<?php _x( 'Esperanto', 'language name', 'wp-typography' ); ?>
<?php _x( 'Spanish', 'language name', 'wp-typography' ); ?>
<?php _x( 'Estonian', 'language name', 'wp-typography' ); ?>
<?php _x( 'Basque', 'language name', 'wp-typography' ); ?>
<?php _x( 'Finnish', 'language name', 'wp-typography' ); ?>
<?php _x( 'French', 'language name', 'wp-typography' ); ?>
<?php _x( 'Friulan', 'language name', 'wp-typography' ); ?>
<?php _x( 'Irish', 'language name', 'wp-typography' ); ?>
<?php _x( 'Galician', 'language name', 'wp-typography' ); ?>
<?php _x( 'Greek (Ancient)', 'language name', 'wp-typography' ); ?>
<?php _x( 'Gujarati', 'language name', 'wp-typography' ); ?>
<?php _x( 'Hindi', 'language name', 'wp-typography' ); ?>
<?php _x( 'Croatian', 'language name', 'wp-typography' ); ?>
<?php _x( 'Upper Sorbian', 'language name', 'wp-typography' ); ?>
<?php _x( 'Hungarian', 'language name', 'wp-typography' ); ?>
<?php _x( 'Armenian', 'language name', 'wp-typography' ); ?>
<?php _x( 'Interlingua', 'language name', 'wp-typography' ); ?>
<?php _x( 'Indonesian', 'language name', 'wp-typography' ); ?>
<?php _x( 'Icelandic', 'language name', 'wp-typography' ); ?>
<?php _x( 'Italian', 'language name', 'wp-typography' ); ?>
<?php _x( 'Georgian', 'language name', 'wp-typography' ); ?>
<?php _x( 'Kurmanji', 'language name', 'wp-typography' ); ?>
<?php _x( 'Kannada', 'language name', 'wp-typography' ); ?>
<?php _x( 'Latin (Classical)', 'language name', 'wp-typography' ); ?>
<?php _x( 'Latin (Liturgical)', 'language name', 'wp-typography' ); ?>
<?php _x( 'Latin', 'language name', 'wp-typography' ); ?>
<?php _x( 'Lithuanian', 'language name', 'wp-typography' ); ?>
<?php _x( 'Latvian', 'language name', 'wp-typography' ); ?>
<?php _x( 'Malayalam', 'language name', 'wp-typography' ); ?>
<?php _x( 'Mongolian (Cyrillic)', 'language name', 'wp-typography' ); ?>
<?php _x( 'Marathi', 'language name', 'wp-typography' ); ?>
<?php _x( 'Norwegian (Bokmål)', 'language name', 'wp-typography' ); ?>
<?php _x( 'Dutch', 'language name', 'wp-typography' ); ?>
<?php _x( 'Norwegian (Nynorsk)', 'language name', 'wp-typography' ); ?>
<?php _x( 'Norwegian', 'language name', 'wp-typography' ); ?>
<?php _x( 'Occitan', 'language name', 'wp-typography' ); ?>
<?php _x( 'Oriya', 'language name', 'wp-typography' ); ?>
<?php _x( 'Panjabi', 'language name', 'wp-typography' ); ?>
<?php _x( 'Polish', 'language name', 'wp-typography' ); ?>
<?php _x( 'Piedmontese', 'language name', 'wp-typography' ); ?>
<?php _x( 'Portuguese', 'language name', 'wp-typography' ); ?>
<?php _x( 'Romansh', 'language name', 'wp-typography' ); ?>
<?php _x( 'Romanian', 'language name', 'wp-typography' ); ?>
<?php _x( 'Russian', 'language name', 'wp-typography' ); ?>
<?php _x( 'Sanskrit', 'language name', 'wp-typography' ); ?>
<?php _x( 'Serbocroatian (Cyrillic)', 'language name', 'wp-typography' ); ?>
<?php _x( 'Serbocroatian (Latin)', 'language name', 'wp-typography' ); ?>
<?php _x( 'Slovak', 'language name', 'wp-typography' ); ?>
<?php _x( 'Slovenian', 'language name', 'wp-typography' ); ?>
<?php _x( 'Serbian (Cyrillic)', 'language name', 'wp-typography' ); ?>
<?php _x( 'Swedish', 'language name', 'wp-typography' ); ?>
<?php _x( 'Tamil', 'language name', 'wp-typography' ); ?>
<?php _x( 'Telugu', 'language name', 'wp-typography' ); ?>
<?php _x( 'Thai', 'language name', 'wp-typography' ); ?>
<?php _x( 'Turkmen', 'language name', 'wp-typography' ); ?>
<?php _x( 'Turkish', 'language name', 'wp-typography' ); ?>
<?php _x( 'Ukrainian', 'language name', 'wp-typography' ); ?>
<?php _x( 'Chinese pinyin (Latin)', 'language name', 'wp-typography' ); ?>
<?php _x( 'German', 'language name', 'wp-typography' ); ?>
<?php _x( 'English (United States)', 'language name', 'wp-typography' ); ?>
