<?php

namespace WP_Typography\Vendor\Masterminds\HTML5\Parser;

/**
 * Emit when the parser has an error.
 */
class ParseError extends \Exception
{
}
